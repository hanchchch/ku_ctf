#!/bin/bash
docker kill kuctf_room_escape 2>/dev/null
docker rm kuctf_room_escape 2>/dev/null
docker run --privileged -p 31002:31000 -dit --name kuctf_room_escape room_escape