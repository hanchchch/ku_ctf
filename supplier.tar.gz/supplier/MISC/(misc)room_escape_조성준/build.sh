#!/bin/bash
docker rmi room_escape
docker build . -t room_escape