#!/bin/bash
docker kill kuctf_room_escape 2>/dev/null
docker rm kuctf_room_escape 2>/dev/null
docker rmi room_escape 2>/dev/null