#!/bin/bash
docker kill kuctf_algo 2>/dev/null
docker rm kuctf_algo 2>/dev/null
docker run --privileged -p 31001:31000 -dit --name kuctf_algo algo