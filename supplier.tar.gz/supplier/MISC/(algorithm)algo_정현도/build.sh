#!/bin/bash
docker rmi algo
docker build . -t algo