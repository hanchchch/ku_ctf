from pwn import *
import copy

p = process("./algo")



def dp(table):
    w = copy.deepcopy(table)
    w.append([])
    w.append([])
    w.append([])
    peb = [[], [], [], [], [], []]
    for j in range(6):
        for i in range(3, 6):
            if i != 5:
                w[i].append(table[0][j] + table[i - 2][j])
            else:
                w[i].append(table[1][j] + table[2][j])

    for i in range(6):
        peb[i].append(w[i][0])
    Max = 0
    for j in range(1, 6):
        for i in range(6):
            if i == 0:
                Max = max(peb[5][j - 1], peb[2][j - 1], peb[1][j - 1])
            elif i == 1:
                Max = max(peb[4][j - 1], peb[2][j - 1], peb[0][j - 1])
            elif i == 2:
                Max = max(peb[3][j - 1], peb[1][j - 1], peb[0][j - 1])
            elif i == 3:
                Max = peb[2][j - 1]
            elif i == 4:
                Max = peb[1][j - 1]
            elif i == 5:
                Max = peb[0][j - 1]
            peb[i].append(w[i][j] + Max)
    return max(peb[0][5], peb[1][5], peb[2][5], peb[3][5], peb[4][5], peb[5][5])




p.recvuntil("...\n")
sleep(5)


for i in range(100):
    table = []
    answer = 0
    p.recvuntil("pwn  : ")
    pwn = p.recvuntil("\n").split()
    p.recvuntil("web  : ")
    web = p.recvuntil("\n").split()
    p.recvuntil("rev  : ")
    rev = p.recvuntil("\n").split()
    pwn = [int(i) for i in pwn]
    web = [int(i) for i in web]
    rev = [int(i) for i in rev]
    table.append(pwn)
    table.append(web)
    table.append(rev)
    p.recv(1024)
    answer = dp(table)
    p.sendline(str(answer))

    
p.interactive()
