#!/bin/bash
docker kill kuctf_algo 2>/dev/null
docker rm kuctf_algo 2>/dev/null
docker rmi algo 2>/dev/null