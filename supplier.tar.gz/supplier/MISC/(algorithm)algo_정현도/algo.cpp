#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <iostream>
#include <unistd.h>


using namespace std;


uint32_t board[3][6];


void usage()
{
    puts(">>> Please give me strategy to get maximum score in CTFs");
    puts(">>> There are 6 rounds in total, and 3 challenges  will be given to me for each round.");
    puts(">>> The flag of the three challenges can only be submitted for the round.");
    puts(">>> Each round, I can only solve one or two problems. (There is no situation I solve anything in each round)");
    puts(">>> Uniquely, if I solve challenge in a particular field in one round, and the next round does not allow me to solve problems in that field.");
    puts(">>> So I'll give you score board of entire round in ctf");
    puts(">>> If you give right score to get maximum score I can make 100 times, I'll will give you strategy too!!");
    printf("\n");
    puts("[Sample]");
    puts("pwn : 100   1 100   1 100   1");
    puts("web :   1 100   1 100   1 100");
    puts("rev : 100   1 100 100 100   1");

    puts(">>> I can make maximum 900 points");
    printf("\n");
    puts(">>> game is start at 5 seconds later...");
}

void show_problem()
{
    /// setting problem
    for(int i = 0; i < 6; i++)
    {
        for(int j = 0; j < 3; j++)
        {
            board[j][i] = 100 + (rand() % 300);
        }
    }

    /// show board
    printf("pwn  : ");
    for(int i = 0; i < 5; i++)
    {
        printf("%d ", board[0][i]);
    }
    printf("%d\n", board[0][5]);

    printf("web  : ");
    for(int i = 0; i < 5; i++)
    {
        printf("%d ", board[1][i]);
    }
    printf("%d\n", board[1][5]);

    printf("rev  : ");
    for(int i = 0; i < 5; i++)
    {
        printf("%d ", board[2][i]);
    }
    printf("%d\n\n", board[2][5]);

    
}

uint32_t dp()
{
    uint32_t peb[6][6];
    uint32_t w[6][6];
    for(int i = 0; i < 6; i++) // make w table
    {
        for(int j = 0; j < 6; j++)
        {
            if ( j < 3 )
            {
                w[j][i] = board[j][i];
            }
            else if ( j >= 3 && j <= 4)
            {
                w[j][i] = board[0][i] + board[j - 2][i];
            }
            else if ( j == 5 )
            {
                w[j][i] = board[1][i] + board[2][i];
            }
        }
    }

    for(int i = 0; i < 6; i++)
    {
        peb[i][0] = w[i][0];
    }
    int Max = 0;
    for(int j = 1; j < 6; j++)
    {
        for(int i = 0; i < 6; i++)
        {
            if ( i == 0 )
            {
                Max = max(peb[5][j - 1] , max(peb[1][j - 1], peb[2][j - 1]));
                
            }
            else if (i == 1)
            {
                Max = max(peb[4][j - 1] , max(peb[0][j - 1], peb[2][j - 1]));
            }
            else if (i == 2)
            {
                Max = max(peb[3][j - 1] , max(peb[0][j - 1], peb[1][j - 1]));
            }
            else if (i == 3)
            {
                Max = peb[2][j - 1];
            }
            else if (i == 4)
            {
                Max = peb[1][j - 1];
            }
            else if (i == 5)
            {
                Max = peb[0][j - 1];
            }
            peb[i][j] = Max + w[i][j];
        }
    }
    /*
    for (int j = 0; j < 6; j++)
    {
        for(int i = 0; i < 6; i++)
        {
            printf("%d ", peb[j][i]);
        }
        printf("%d\n", peb[j][5]);
    }
    */
    
    return max(peb[0][5], max(peb[1][5], max(peb[2][5], max(peb[3][5], max(peb[4][5], peb[5][5])))) );

}

void recv_answer()
{
    uint32_t answer;
    clock_t start = clock();
    scanf("%u", &answer);
    if ( ((clock() - start) / CLOCKS_PER_SEC) > 11)
    {
        printf("Time out!!\n");
        exit(0);
    }
    uint32_t my_answer = dp();
    if ( answer == my_answer )
    {
        puts("Good!!");
    }
    else
    {
        puts("Noooo...");
        exit(0);
    }

}

int main()
{
    setvbuf(stdin, 0LL, 2, 0LL);
    setvbuf(stdout, 0LL, 2, 0LL);
    setvbuf(stderr, 0LL, 2, 0LL);
    srand(time(NULL));
    usage();
    sleep(5);
    for(int i = 1; i <= 100; i++)
    {
        printf("[Stage %d]\n", i);
        show_problem();
        printf("Give me answer in 10 seconds >> ");
        recv_answer();
    }
    puts("KOREA{DP_1s_0nly_4lgorithm_I_know...}");
}