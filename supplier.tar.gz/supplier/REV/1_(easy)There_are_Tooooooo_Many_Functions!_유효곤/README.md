# There is Tooooooo Functions!
> I made really many functions and some of them have a char of the flag.
> If CTFer use the IDAPython and IDAAPI, then can solve easily!

prob1.c : source code
prob1.py : source code generator
prob1_sol.py : solver. (IDAPython)
There_are_Tooooooo_Functions! : Challenge Binary

### How to Make
gcc -o There_are_Tooooooo_Functions!**
strip There_are_Tooooooo_Functions!

Flag : `KOREA{WELCOME_TO_EASY_REVERSING_CHALLENGE}`

