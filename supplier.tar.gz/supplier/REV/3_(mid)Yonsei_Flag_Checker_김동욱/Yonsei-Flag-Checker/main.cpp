#include <stdio.h>
#include <string.h>
// KOREA{M0M!_my_h3xr4y_d1d_n07_w0rk_1n_y0ns31_f149_ch3ck3r!@!@}

char Correct_hash[123] = "77a7124403c79315367397d6553043537715b39037a61277554513b5a7c7a3d4f533120655e51306e477e384877397153775f552c5e374141414341414";
int main()
{
	__asm {
		cmp eax, 10;
		je round;
	}
	char flag[62] = { 0, };
	printf("Hello, I'm Flag-Checker of Yonsei CTF.\n");
	printf("Flag: ");
	scanf("%s", flag);
	
	if (strlen(flag) != 61)
	{
		printf("No. :(");
		return 0;
	}

	char key[6];
	memcpy(key, flag, 6);

	int i;
	char tmp[61] = { 0, };
	for (i = 0; i < 61; i++)
	{
		tmp[i] = flag[i] ^ (key[i % 6] - 'A');
	}
	char hash[123] = { 0, };
	
	for (i = 0; i < 61; i++)
	{
		char temp[3] = { 0, };
		sprintf(temp, "%02x", tmp[i]);
		strcat(hash, temp);
	}

	char result[123] = { 0, };
	for (i = 0; i < 122; i++)
	{
		result[i] = hash[121 - i];
	}
	if (!strncmp(result, Correct_hash, 122))
		printf("Congrat!\n");
	else
		printf("No. :(");
	return 0;

round:
	printf("Congrat!\n");

	return 0;
}