# Reversing_Package
> In this binary, there are Anti-debug (Anti Trace, Anti-breakpoint), Hot patching, CRC32 Technics.
> If CTFer know the many kinds of RE Technics, then can solve this Chellenge.

## How To Make
Makefile : **make**
Environment : **ubuntu 18.04**

Solution : **Solution.md**

Flag: `You_could_feel_the_various_flavors_of_reversing,right?`

