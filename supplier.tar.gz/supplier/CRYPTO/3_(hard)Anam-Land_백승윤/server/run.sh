#!/bin/sh
cd /home/casino
python3 main.py
