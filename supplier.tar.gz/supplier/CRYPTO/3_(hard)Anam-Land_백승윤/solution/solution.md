# Anam-Land

주어지는 파일 : `main.py`

**Flag** : `KOREA{I_M3ss3d_up_my_R4nd0m_G3n3r4t0R}`



### Intended solution

```
1. Subset Sum Problem
```



귀찮으니 코드만 solution 폴더에 첨부하였습니다. 괜찮지요?

