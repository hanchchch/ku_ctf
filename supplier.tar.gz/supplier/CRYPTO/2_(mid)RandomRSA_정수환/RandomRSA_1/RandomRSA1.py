from math import gcd
from Crypto.Util.number import bytes_to_long, getPrime, isPrime
from secret import flag, flag1, flag2
assert flag == flag1 + flag2


def getTwinPrime(N):
    while True:
        p = getPrime(N)
        if isPrime(p + 2):
            return p


KEYSIZE = 1024

p = getTwinPrime(KEYSIZE)
q1 = getPrime(KEYSIZE)
q2 = getPrime(KEYSIZE)

n1 = p * q1
n2 = (p + 2) * q2
e2 = bytes_to_long(b'KOREA_2020')
print(hex(n1))
print(hex((p - 1) * (q1 - 1)))

print(hex(n2))
print(hex(pow(bytes_to_long(flag1), e2, n2)))
