docker kill kuctf_yonsei_file_manager 2>/dev/null
docker rm kuctf_yonsei_file_manager 2>/dev/null
docker run -dit -p 31008:8080 --name kuctf_yonsei_file_manager yonsei_file_manager
