docker rmi yonsei_file_manager
docker build . -t yonsei_file_manager