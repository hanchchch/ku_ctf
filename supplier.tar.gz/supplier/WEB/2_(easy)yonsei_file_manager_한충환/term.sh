#!/bin/bash
docker kill kuctf_yonsei_file_manager 2>/dev/null
docker rm kuctf_yonsei_file_manager 2>/dev/null
docker rmi yonsei_file_manager 2>/dev/null