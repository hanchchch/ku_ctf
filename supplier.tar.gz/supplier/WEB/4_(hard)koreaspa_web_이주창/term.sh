#!/bin/bash
docker kill kuctf_koreaspa 2>/dev/null
docker rm kuctf_koreaspa 2>/dev/null
docker rmi koreaspa 2>/dev/null