docker run -it -p 8080:8080 --name kuctf_koreaspa koreaspa
