const express = require('express')
const router = express.Router()

const { verifyNotLogin, addslashes, verifyLogin } = require('../util')
const { login, register, encrypt, decrypt } = require('../native/module.node')

router.get('/', (req, res) => {
    let logined = false
    if(typeof req.cookies.token !== 'undefined'){
        console.log("FUCK")
        logined = decrypt(req.cookies.token)
    }

    res.status(200).render('index', { logined })
})

router.get('/error', (req, res) => {
    res.render('error')
})

router.post('/login', verifyNotLogin, (req, res) => {
    const { id, pw } = req.body

    if(login(addslashes(id), addslashes(pw)) == 1){
        const token = encrypt(id)
        res.cookie('token', token)
        res.status(200).redirect('/')
    } else {
        res.status(401).redirect('/error')
    }
})

router.post('/register', verifyNotLogin, (req, res) => {
    const { id, pw } = req.body
 
    if(register(addslashes(id), addslashes(pw)) == 1) res.status(200).redirect('/')
    else res.status(401).redirect('/error')
})

router.get('/logout', (req, res) => {
    res.clearCookie("token")
    res.status(200).redirect('/')
})

module.exports = router