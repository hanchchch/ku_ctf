#!/bin/sh

cd src

#gcc --shared -fPIC  -o db.o db.c -lmysqlclient -I/usr/include/mysql/
#g++ -std=c++11 --shared -fPIC  -o module.o module.cpp -I/usr/include/mysql/ -I/usr/include/node/
g++ -std=c++11 --shared -fPIC -o module module.cpp -lmysqlclient -I/usr/include/mysql/ -I/usr/include/node/ -w 

#rm db.o module.o
mv module ../module.node
cd ..