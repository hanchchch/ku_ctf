#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <mysql.h>
#include <node/node.h>


///////////////////////////////////////////// BASE64 WRAPPER ////////////////////////////////////////////

const char b64chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

size_t b64_encoded_size(size_t inlen)
{
	size_t ret;

	ret = inlen;
	if (inlen % 3 != 0)
		ret += 3 - (inlen % 3);
	ret /= 3;
	ret *= 4;

	return ret;
}

char *b64_encode(const unsigned char *in, size_t len)
{
	char   *out;
	size_t  elen;
	size_t  i;
	size_t  j;
	size_t  v;

	if (in == NULL || len == 0)
		return NULL;

	elen = b64_encoded_size(len);
	out  = (char *)malloc(elen+1);
	out[elen] = '\0';

	for (i=0, j=0; i<len; i+=3, j+=4) {
		v = in[i];
		v = i+1 < len ? v << 8 | in[i+1] : v << 8;
		v = i+2 < len ? v << 8 | in[i+2] : v << 8;

		out[j]   = b64chars[(v >> 18) & 0x3F];
		out[j+1] = b64chars[(v >> 12) & 0x3F];
		if (i+1 < len) {
			out[j+2] = b64chars[(v >> 6) & 0x3F];
		} else {
			out[j+2] = '=';
		}
		if (i+2 < len) {
			out[j+3] = b64chars[v & 0x3F];
		} else {
			out[j+3] = '=';
		}
	}

	return out;
}

size_t b64_decoded_size(const char *in)
{
	size_t len;
	size_t ret;
	size_t i;

	if (in == NULL)
		return 0;

	len = strlen(in);
	ret = len / 4 * 3;

	for (i=len; i-->0; ) {
		if (in[i] == '=') {
			ret--;
		} else {
			break;
		}
	}

	return ret;
}

int b64invs[] = { 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58,
	59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5,
	6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
	21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28,
	29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42,
	43, 44, 45, 46, 47, 48, 49, 50, 51 };

int b64_isvalidchar(char c)
{
	if (c >= '0' && c <= '9')
		return 1;
	if (c >= 'A' && c <= 'Z')
		return 1;
	if (c >= 'a' && c <= 'z')
		return 1;
	if (c == '+' || c == '/' || c == '=')
		return 1;
	return 0;
}

int b64_decode(const char *in, unsigned char *out, size_t outlen)
{
	size_t len;
	size_t i;
	size_t j;
	int    v;

	if (in == NULL || out == NULL)
		return 0;

	len = strlen(in);
	if (outlen < b64_decoded_size(in) || len % 4 != 0)
		return 0;

	for (i=0; i<len; i++) {
		if (!b64_isvalidchar(in[i])) {
			return 0;
		}
	}

	for (i=0, j=0; i<len; i+=4, j+=3) {
		v = b64invs[in[i]-43];
		v = (v << 6) | b64invs[in[i+1]-43];
		v = in[i+2]=='=' ? v << 6 : (v << 6) | b64invs[in[i+2]-43];
		v = in[i+3]=='=' ? v << 6 : (v << 6) | b64invs[in[i+3]-43];

		out[j] = (v >> 16) & 0xFF;
		if (in[i+2] != '=')
			out[j+1] = (v >> 8) & 0xFF;
		if (in[i+3] != '=')
			out[j+2] = v & 0xFF;
	}

	return 1;
}


////////////////////////////////////////////// AES WRAPPER /////////////////////////////////////////////

#define AES_BLOCKLEN 16 //Block length in bytes AES is 128b block only
#define AES_KEYLEN 16   // Key length in bytes
#define AES_keyExpSize 176

#define Nb 4
#define Nk 4       
#define Nr 10  

struct AES_ctx
{
  uint8_t RoundKey[AES_keyExpSize];
  uint8_t Iv[AES_BLOCKLEN];
};

void AES_init_ctx(struct AES_ctx* ctx, const uint8_t* key);
void AES_init_ctx_iv(struct AES_ctx* ctx, const uint8_t* key, const uint8_t* iv);
void AES_ctx_set_iv(struct AES_ctx* ctx, const uint8_t* iv);

void AES_CBC_encrypt_buffer(struct AES_ctx* ctx, uint8_t* buf, uint32_t length);
void AES_CBC_decrypt_buffer(struct AES_ctx* ctx, uint8_t* buf, uint32_t length);
void AES_CBC_encrypt_bufferEx(struct AES_ctx *ctx,uint8_t* buf, uint8_t* out, uint32_t length);

typedef uint8_t state_t[4][4];

static const uint8_t sbox[256] = {
  //0     1    2      3     4    5     6     7      8    9     A      B    C     D     E     F
  0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
  0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
  0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
  0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
  0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
  0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
  0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
  0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
  0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
  0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
  0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
  0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
  0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
  0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
  0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
  0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16 };

static const uint8_t rsbox[256] = {
  0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7, 0xfb,
  0x7c, 0xe3, 0x39, 0x82, 0x9b, 0x2f, 0xff, 0x87, 0x34, 0x8e, 0x43, 0x44, 0xc4, 0xde, 0xe9, 0xcb,
  0x54, 0x7b, 0x94, 0x32, 0xa6, 0xc2, 0x23, 0x3d, 0xee, 0x4c, 0x95, 0x0b, 0x42, 0xfa, 0xc3, 0x4e,
  0x08, 0x2e, 0xa1, 0x66, 0x28, 0xd9, 0x24, 0xb2, 0x76, 0x5b, 0xa2, 0x49, 0x6d, 0x8b, 0xd1, 0x25,
  0x72, 0xf8, 0xf6, 0x64, 0x86, 0x68, 0x98, 0x16, 0xd4, 0xa4, 0x5c, 0xcc, 0x5d, 0x65, 0xb6, 0x92,
  0x6c, 0x70, 0x48, 0x50, 0xfd, 0xed, 0xb9, 0xda, 0x5e, 0x15, 0x46, 0x57, 0xa7, 0x8d, 0x9d, 0x84,
  0x90, 0xd8, 0xab, 0x00, 0x8c, 0xbc, 0xd3, 0x0a, 0xf7, 0xe4, 0x58, 0x05, 0xb8, 0xb3, 0x45, 0x06,
  0xd0, 0x2c, 0x1e, 0x8f, 0xca, 0x3f, 0x0f, 0x02, 0xc1, 0xaf, 0xbd, 0x03, 0x01, 0x13, 0x8a, 0x6b,
  0x3a, 0x91, 0x11, 0x41, 0x4f, 0x67, 0xdc, 0xea, 0x97, 0xf2, 0xcf, 0xce, 0xf0, 0xb4, 0xe6, 0x73,
  0x96, 0xac, 0x74, 0x22, 0xe7, 0xad, 0x35, 0x85, 0xe2, 0xf9, 0x37, 0xe8, 0x1c, 0x75, 0xdf, 0x6e,
  0x47, 0xf1, 0x1a, 0x71, 0x1d, 0x29, 0xc5, 0x89, 0x6f, 0xb7, 0x62, 0x0e, 0xaa, 0x18, 0xbe, 0x1b,
  0xfc, 0x56, 0x3e, 0x4b, 0xc6, 0xd2, 0x79, 0x20, 0x9a, 0xdb, 0xc0, 0xfe, 0x78, 0xcd, 0x5a, 0xf4,
  0x1f, 0xdd, 0xa8, 0x33, 0x88, 0x07, 0xc7, 0x31, 0xb1, 0x12, 0x10, 0x59, 0x27, 0x80, 0xec, 0x5f,
  0x60, 0x51, 0x7f, 0xa9, 0x19, 0xb5, 0x4a, 0x0d, 0x2d, 0xe5, 0x7a, 0x9f, 0x93, 0xc9, 0x9c, 0xef,
  0xa0, 0xe0, 0x3b, 0x4d, 0xae, 0x2a, 0xf5, 0xb0, 0xc8, 0xeb, 0xbb, 0x3c, 0x83, 0x53, 0x99, 0x61,
  0x17, 0x2b, 0x04, 0x7e, 0xba, 0x77, 0xd6, 0x26, 0xe1, 0x69, 0x14, 0x63, 0x55, 0x21, 0x0c, 0x7d };

static const uint8_t Rcon[11] = { 0x8d, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36 };


const uint8_t key[] = "IZ*ONE82nuinsdau";
    
const uint8_t iv[]  = "IZ*ONE_PERMANENT";


#pragma inline
void *myMemcpy(void *s1, const void *s2, size_t n)
{       /* copy char s2[n] to s1[n] in any order */
    char *su1 = (char *)s1;
    const char *su2 = (const char *)s2;

    for (; 0 < n; ++su1, ++su2, --n)
      *su1 = *su2;
    return (s1);
}

#define getSBoxValue(num) (sbox[(num)])
#define getSBoxInvert(num) (rsbox[(num)])

// This function produces Nb(Nr+1) round keys. The round keys are used in each round to decrypt the states. 
static void KeyExpansion(uint8_t* RoundKey, const uint8_t* Key)
{
  unsigned i, j, k;
  uint8_t tempa[4]; // Used for the column/row operations
  
  // The first round key is the key itself.
  for (i = 0; i < Nk; ++i)
  {
    RoundKey[(i * 4) + 0] = Key[(i * 4) + 0];
    RoundKey[(i * 4) + 1] = Key[(i * 4) + 1];
    RoundKey[(i * 4) + 2] = Key[(i * 4) + 2];
    RoundKey[(i * 4) + 3] = Key[(i * 4) + 3];
  }

  // All other round keys are found from the previous round keys.
  for (i = Nk; i < Nb * (Nr + 1); ++i)
  {
    {
      k = (i - 1) * 4;
      tempa[0]=RoundKey[k + 0];
      tempa[1]=RoundKey[k + 1];
      tempa[2]=RoundKey[k + 2];
      tempa[3]=RoundKey[k + 3];

    }

    if (i % Nk == 0)
    {
      // This function shifts the 4 bytes in a word to the left once.
      // [a0,a1,a2,a3] becomes [a1,a2,a3,a0]

      // Function RotWord()
      {
        const uint8_t u8tmp = tempa[0];
        tempa[0] = tempa[1];
        tempa[1] = tempa[2];
        tempa[2] = tempa[3];
        tempa[3] = u8tmp;
      }

      // SubWord() is a function that takes a four-byte input word and 
      // applies the S-box to each of the four bytes to produce an output word.

      // Function Subword()
      {
        tempa[0] = getSBoxValue(tempa[0]);
        tempa[1] = getSBoxValue(tempa[1]);
        tempa[2] = getSBoxValue(tempa[2]);
        tempa[3] = getSBoxValue(tempa[3]);
      }

      tempa[0] = tempa[0] ^ Rcon[i/Nk];
    }
    j = i * 4; k=(i - Nk) * 4;
    RoundKey[j + 0] = RoundKey[k + 0] ^ tempa[0];
    RoundKey[j + 1] = RoundKey[k + 1] ^ tempa[1];
    RoundKey[j + 2] = RoundKey[k + 2] ^ tempa[2];
    RoundKey[j + 3] = RoundKey[k + 3] ^ tempa[3];
  }
}

void AES_init_ctx(struct AES_ctx* ctx, const uint8_t* key)
{
  KeyExpansion(ctx->RoundKey, key);
}

void AES_init_ctx_iv(struct AES_ctx* ctx, const uint8_t* key, const uint8_t* iv)
{
  KeyExpansion(ctx->RoundKey, key);
  myMemcpy (ctx->Iv, (uint8_t*)iv, AES_BLOCKLEN);
}

void AES_ctx_set_iv(struct AES_ctx* ctx, const uint8_t* iv)
{
  myMemcpy (ctx->Iv, (uint8_t*)iv, AES_BLOCKLEN);
}

// This function adds the round key to state.
// The round key is added to the state by an XOR function.
static void AddRoundKey(uint8_t round,state_t* state,uint8_t* RoundKey)
{
  uint8_t i,j;
  for (i = 0; i < 4; ++i)
  {
    for (j = 0; j < 4; ++j)
    {
      (*state)[i][j] ^= RoundKey[(round * Nb * 4) + (i * Nb) + j];
    }
  }
}

// This function adds the round key to state.
// The round key is added to the state by an XOR function.
static void AddRoundKeyEx(uint8_t round, state_t* state, state_t* out, uint8_t* RoundKey)
{
  uint8_t i,j;
  for (i = 0; i < 4; ++i)
  {
    for (j = 0; j < 4; ++j)
    {
      (*out)[i][j] = (*state)[i][j] ^ RoundKey[(round * Nb * 4) + (i * Nb) + j];
    }
  }
}

// The SubBytes Function Substitutes the values in the
// state matrix with values in an S-box.
static void SubBytes(state_t* state)
{
  uint8_t i, j;
  for (i = 0; i < 4; ++i)
  {
    for (j = 0; j < 4; ++j)
    {
      (*state)[j][i] = getSBoxValue((*state)[j][i]);
    }
  }
}

// The ShiftRows() function shifts the rows in the state to the left.
// Each row is shifted with different offset.
// Offset = Row number. So the first row is not shifted.
static void ShiftRows(state_t* state)
{
  uint8_t temp;

  // Rotate first row 1 columns to left  
  temp           = (*state)[0][1];
  (*state)[0][1] = (*state)[1][1];
  (*state)[1][1] = (*state)[2][1];
  (*state)[2][1] = (*state)[3][1];
  (*state)[3][1] = temp;

  // Rotate second row 2 columns to left  
  temp           = (*state)[0][2];
  (*state)[0][2] = (*state)[2][2];
  (*state)[2][2] = temp;

  temp           = (*state)[1][2];
  (*state)[1][2] = (*state)[3][2];
  (*state)[3][2] = temp;

  // Rotate third row 3 columns to left
  temp           = (*state)[0][3];
  (*state)[0][3] = (*state)[3][3];
  (*state)[3][3] = (*state)[2][3];
  (*state)[2][3] = (*state)[1][3];
  (*state)[1][3] = temp;
}

static uint8_t xtime(uint8_t x)
{
  return ((x<<1) ^ (((x>>7) & 1) * 0x1b));
}

// MixColumns function mixes the columns of the state matrix
static void MixColumns(state_t* state)
{
  uint8_t i;
  uint8_t Tmp, Tm, t;
  for (i = 0; i < 4; ++i)
  {  
    t   = (*state)[i][0];
    Tmp = (*state)[i][0] ^ (*state)[i][1] ^ (*state)[i][2] ^ (*state)[i][3] ;
    Tm  = (*state)[i][0] ^ (*state)[i][1] ; Tm = xtime(Tm);  (*state)[i][0] ^= Tm ^ Tmp ;
    Tm  = (*state)[i][1] ^ (*state)[i][2] ; Tm = xtime(Tm);  (*state)[i][1] ^= Tm ^ Tmp ;
    Tm  = (*state)[i][2] ^ (*state)[i][3] ; Tm = xtime(Tm);  (*state)[i][2] ^= Tm ^ Tmp ;
    Tm  = (*state)[i][3] ^ t ;              Tm = xtime(Tm);  (*state)[i][3] ^= Tm ^ Tmp ;
  }
}

// Multiply is used to multiply numbers in the field GF(2^8)
// Note: The last call to xtime() is unneeded, but often ends up generating a smaller binary
//       The compiler seems to be able to vectorize the operation better this way.
//       See https://github.com/kokke/tiny-AES-c/pull/34
#define Multiply(x, y)                                \
      (  ((y & 1) * x) ^                              \
      ((y>>1 & 1) * xtime(x)) ^                       \
      ((y>>2 & 1) * xtime(xtime(x))) ^                \
      ((y>>3 & 1) * xtime(xtime(xtime(x)))) ^         \
      ((y>>4 & 1) * xtime(xtime(xtime(xtime(x))))))   \


// MixColumns function mixes the columns of the state matrix.
// The method used to multiply may be difficult to understand for the inexperienced.
// Please use the references to gain more information.
static void InvMixColumns(state_t* state)
{
  int i;
  uint8_t a, b, c, d;
  for (i = 0; i < 4; ++i)
  { 
    a = (*state)[i][0];
    b = (*state)[i][1];
    c = (*state)[i][2];
    d = (*state)[i][3];

    (*state)[i][0] = Multiply(a, 0x0e) ^ Multiply(b, 0x0b) ^ Multiply(c, 0x0d) ^ Multiply(d, 0x09);
    (*state)[i][1] = Multiply(a, 0x09) ^ Multiply(b, 0x0e) ^ Multiply(c, 0x0b) ^ Multiply(d, 0x0d);
    (*state)[i][2] = Multiply(a, 0x0d) ^ Multiply(b, 0x09) ^ Multiply(c, 0x0e) ^ Multiply(d, 0x0b);
    (*state)[i][3] = Multiply(a, 0x0b) ^ Multiply(b, 0x0d) ^ Multiply(c, 0x09) ^ Multiply(d, 0x0e);
  }
}


// The SubBytes Function Substitutes the values in the
// state matrix with values in an S-box.
static void InvSubBytes(state_t* state)
{
  uint8_t i, j;
  for (i = 0; i < 4; ++i)
  {
    for (j = 0; j < 4; ++j)
    {
      (*state)[j][i] = getSBoxInvert((*state)[j][i]);
    }
  }
}

static void InvShiftRows(state_t* state)
{
  uint8_t temp;

  // Rotate first row 1 columns to right  
  temp = (*state)[3][1];
  (*state)[3][1] = (*state)[2][1];
  (*state)[2][1] = (*state)[1][1];
  (*state)[1][1] = (*state)[0][1];
  (*state)[0][1] = temp;

  // Rotate second row 2 columns to right 
  temp = (*state)[0][2];
  (*state)[0][2] = (*state)[2][2];
  (*state)[2][2] = temp;

  temp = (*state)[1][2];
  (*state)[1][2] = (*state)[3][2];
  (*state)[3][2] = temp;

  // Rotate third row 3 columns to right
  temp = (*state)[0][3];
  (*state)[0][3] = (*state)[1][3];
  (*state)[1][3] = (*state)[2][3];
  (*state)[2][3] = (*state)[3][3];
  (*state)[3][3] = temp;
}


// Cipher is the main function that encrypts the PlainText.
static void Cipher(state_t* state, uint8_t* RoundKey)
{
  uint8_t round = 0;

  // Add the First round key to the state before starting the rounds.
  AddRoundKey(0, state, RoundKey); 
  
  // There will be Nr rounds.
  // The first Nr-1 rounds are identical.
  // These Nr-1 rounds are executed in the loop below.
  for (round = 1; round < Nr; ++round)
  {
    SubBytes(state);
    ShiftRows(state);
    MixColumns(state);
    AddRoundKey(round, state, RoundKey);
  }
  
  // The last round is given below.
  // The MixColumns function is not here in the last round.
  SubBytes(state);
  ShiftRows(state);
  AddRoundKey(Nr, state, RoundKey);
}


// Cipher is the main function that encrypts the PlainText.
static void CipherEx(state_t* state, state_t* out, uint8_t* RoundKey)
{
  uint8_t round = 0;

  // Add the First round key to the state before starting the rounds.
  AddRoundKeyEx(0, state, out, RoundKey); 
  
  // There will be Nr rounds.
  // The first Nr-1 rounds are identical.
  // These Nr-1 rounds are executed in the loop below.
  for (round = 1; round < Nr; ++round)
  {
    SubBytes(out);
    ShiftRows(out);
    MixColumns(out);
    AddRoundKey(round, out, RoundKey);
  }
  
  // The last round is given below.
  // The MixColumns function is not here in the last round.
  SubBytes(out);
  ShiftRows(out);
  AddRoundKey(Nr, out, RoundKey);
}


static void InvCipher(state_t* state,uint8_t* RoundKey)
{
  uint8_t round = 0;

  // Add the First round key to the state before starting the rounds.
  AddRoundKey(Nr, state, RoundKey); 

  // There will be Nr rounds.
  // The first Nr-1 rounds are identical.
  // These Nr-1 rounds are executed in the loop below.
  for (round = (Nr - 1); round > 0; --round)
  {
    InvShiftRows(state);
    InvSubBytes(state);
    AddRoundKey(round, state, RoundKey);
    InvMixColumns(state);
  }
  
  // The last round is given below.
  // The MixColumns function is not here in the last round.
  InvShiftRows(state);
  InvSubBytes(state);
  AddRoundKey(0, state, RoundKey);
}


/*****************************************************************************/
/* Public functions:                                                         */
/*****************************************************************************/
static void XorWithIv(uint8_t* buf, uint8_t* Iv)
{
  uint8_t i;
  for (i = 0; i < AES_BLOCKLEN; ++i) // The block in AES is always 128bit no matter the key size
  {
    buf[i] ^= Iv[i];
  }
}

void AES_CBC_encrypt_buffer(struct AES_ctx *ctx,uint8_t* buf, uint32_t length)
{
  uintptr_t i;
  uint8_t *Iv = ctx->Iv;
  for (i = 0; i < length; i += AES_BLOCKLEN)
  {
    XorWithIv(buf, Iv);
    Cipher((state_t*)buf, ctx->RoundKey);
    Iv = buf;
    buf += AES_BLOCKLEN;
    //printf("Step %d - %d", i/16, i);
  }
  /* store Iv in ctx for next call */
  myMemcpy(ctx->Iv, Iv, AES_BLOCKLEN);
}
void AES_CBC_encrypt_bufferEx(struct AES_ctx *ctx,uint8_t* buf, uint8_t* out, uint32_t length)
{
  uintptr_t i;
  uint8_t *Iv = ctx->Iv;
  for (i = 0; i < length; i += AES_BLOCKLEN)
  {
    XorWithIv(buf, Iv);
    CipherEx((state_t*)buf, (state_t*)out, ctx->RoundKey);
    Iv = out;
    buf += AES_BLOCKLEN;
    out += AES_BLOCKLEN;
    //printf("Step %d - %d", i/16, i);
  }
  /* store Iv in ctx for next call */
  myMemcpy(ctx->Iv, Iv, AES_BLOCKLEN);
}

void AES_CBC_decrypt_buffer(struct AES_ctx* ctx, uint8_t* buf,  uint32_t length)
{
  uintptr_t i;
  uint8_t storeNextIv[AES_BLOCKLEN];
  for (i = 0; i < length; i += AES_BLOCKLEN)
  {
    myMemcpy(storeNextIv, buf, AES_BLOCKLEN);
    InvCipher((state_t*)buf, ctx->RoundKey);
    XorWithIv(buf, ctx->Iv);
    myMemcpy(ctx->Iv, storeNextIv, AES_BLOCKLEN);
    buf += AES_BLOCKLEN;
  }
}


char* padding(char* str) { 
  if (strlen(str) % 16 == 0) {
      char* res = (char*)calloc(strlen(str) + 16 + 1, sizeof(char));  
      memcpy(res, str, strlen(str)); 
      memset(res + strlen(str), 16, 16);

      return res; 
  }
  int padd = 16 - strlen(str) % 16; 
  char* res = (char*)calloc(strlen(str) + padd + 1, sizeof(char));  
  memcpy(res, str, strlen(str));
  memset(res + strlen(str), (char)padd, padd);

  return res; 
}

char *unpadding(char *str){
  int size = strlen(str);
  int dd = str[strlen(str)-1];
  if(dd > 16) return str;

  char *result = (char *)malloc(size);
  memset(result, 0, size);
  memcpy(result, str, size-dd);

  return result;
}

////////////////////////////////////////////// DB WRAPPER //////////////////////////////////////////////

#define DBERROR -1
#define QUERYERROR 0
#define ERROR 0
#define SUCCESS 1

#define SERVER "127.0.0.1"
#define USER "korea"
#define PASSWORD "iz_one_permanent"
#define DATABASE "koreaspa"

MYSQL *NativeConnectDatabase(char *server, char *user, char *password, char *database){
  MYSQL *conn = mysql_init(NULL);
  if (!mysql_real_connect(conn, server, user, password, database, 0, NULL, 0)) {
    perror("mysql_real_connect");
    return ERROR;
  }
  return conn;
}

int NativeLogin(const char *id, const char *pw){
    MYSQL *conn = NativeConnectDatabase(SERVER, USER, PASSWORD, DATABASE);
    if(conn == 0) return DBERROR; 

    char *query = (char *)malloc(0x1000);
    memset(query, 0, 0x1000);

    snprintf(query, 0x1000, "SELECT no FROM `users` WHERE id='%s' and password='%s'", id, pw);
    if( mysql_query(conn, query) != 0 ){
        perror("mysql_query");
        free(query);
        mysql_close(conn);
        return DBERROR;
    }
    free(query);

    MYSQL_RES *result = mysql_store_result(conn);  
    if( mysql_num_rows(result) != 0 ){
        mysql_free_result(result);
        mysql_close(conn);
        return SUCCESS;
    } else {
        mysql_free_result(result);
        mysql_close(conn);
        return ERROR;
    }
}

int NativeRegister(const char *id, const char *pw){
    MYSQL *conn = NativeConnectDatabase(SERVER, USER, PASSWORD, DATABASE);
    if(conn == 0) return DBERROR; 

    char *query = (char *)malloc(0x1000);
    memset(query, 0, 0x1000);

    snprintf(query, 0x1000, "SELECT no FROM `users` WHERE id='%s'", id); // check duplicate
    if( mysql_query(conn, query) != 0 ){
        perror("mysql_query");
        free(query);
        mysql_close(conn);
        return DBERROR;
    }

    MYSQL_RES *result = mysql_store_result(conn);  
    if( mysql_num_rows(result) != 0 ){
        mysql_free_result(result);
        mysql_close(conn);
        return ERROR;
    } 

    memset(query, 0, 0x1000);
    snprintf(query, 0x1000, "INSERT INTO `users` VALUES(0, '%s', '%s')", id, pw);

    if( mysql_query(conn, query) != 0 ){
        perror("mysql_query");
        free(query);
        mysql_close(conn);
        return ERROR;
    }
    free(query);
    mysql_close(conn);
    return SUCCESS;
}

int NativeWriteBoard(const char *title, const char *category, const char *content, const char *file, const char *author){
    MYSQL *conn = NativeConnectDatabase(SERVER, USER, PASSWORD, DATABASE);
    if(conn == 0) return DBERROR; 

    char *query = (char *)malloc(0x2000);
    memset(query, 0, 0x2000);

    snprintf(query, 0x2000, "INSERT INTO `board` VALUES(0, '%s', '%s', '%s', '%s', '%s')", title, category, content, file, author);

    if( mysql_query(conn, query) != 0 ){
        perror("mysql_query");
        free(query);
        mysql_close(conn);
        return ERROR;
    }
    free(query);
    mysql_close(conn);
    return SUCCESS;
}

const char *NativeGetFilePath(int no){
    MYSQL *conn = NativeConnectDatabase(SERVER, USER, PASSWORD, DATABASE);
    if(conn == 0) return ERROR; 

    char *query = (char *)malloc(0x1000);
    memset(query, 0, 0x1000);

    snprintf(query, 0x1000, "SELECT file FROM board WHERE no=%d", no);

    if( mysql_query(conn, query) != 0 ){
        perror("mysql_query");
        free(query);
        mysql_close(conn);
        return ERROR;
    }
    free(query);

    MYSQL_RES *result = mysql_store_result(conn);  
    if( mysql_num_rows(result) != 0 ){
        MYSQL_ROW row = mysql_fetch_row(result);
        mysql_free_result(result);
        mysql_close(conn);
        return row[0];
    } else {
        mysql_free_result(result);
        mysql_close(conn);
        return ERROR;
    }

    mysql_close(conn);
    return ERROR;
}

int NativeCheckAuthor(int no, const char *author){
    MYSQL *conn = NativeConnectDatabase(SERVER, USER, PASSWORD, DATABASE);
    if(conn == 0) return DBERROR; 

    char *query = (char *)malloc(0x1000);
    memset(query, 0, 0x1000);

    snprintf(query, 0x1000, "SELECT no FROM `board` WHERE no=%d and author='%s'", no, author);
    if( mysql_query(conn, query) != 0 ){
        perror("mysql_query");
        free(query);
        mysql_close(conn);
        return DBERROR;
    }
    free(query);

    MYSQL_RES *result = mysql_store_result(conn);  
    if( mysql_num_rows(result) != 0 ){
        mysql_free_result(result);
        mysql_close(conn);
        return SUCCESS;
    } else {
        mysql_free_result(result);
        mysql_close(conn);
        return ERROR;
    }
}

struct board {
  int no;
  char *title;
  char *category;
  char *content;
  char *file;
  char *author;
  struct board *next;
};

struct board* NativeListBoard(const char *category, const char *author){
    MYSQL *conn = NativeConnectDatabase(SERVER, USER, PASSWORD, DATABASE);
    if(conn == 0) return ERROR; 

    char *query = (char *)malloc(0x1000);
    memset(query, 0, 0x1000);

    snprintf(query, 0x1000, "SELECT no, title, author FROM `board` WHERE category='%s' and author='%s' order by no desc", category, author);
    if( mysql_query(conn, query) != 0 ){
        perror("mysql_query");
        free(query);
        mysql_close(conn);
        return ERROR;
    }
    free(query);

    MYSQL_RES *result = mysql_store_result(conn);  
    int count = mysql_num_rows(result);

    struct board *res = (struct board *)malloc(sizeof(struct board));
    memset(res, 0, sizeof(struct board));
    struct board *start = res;
    MYSQL_ROW row = 0;
    if(count == 0) {
      mysql_free_result(result);
      mysql_close(conn);
      return 0;
    }

    for(int i=0; i<count - 1; i++){
      row = mysql_fetch_row(result);
      res->no = atoi(row[0]);
      res->title = strdup(row[1]);
      res->author = strdup(row[2]);
      struct board *tmp = (struct board *)malloc(sizeof(struct board));
      memset(tmp, 0, sizeof(struct board));
      res->next = tmp;
      res = res->next;
    }

    row = mysql_fetch_row(result);
    res->no = atoi(row[0]);
    res->title = strdup(row[1]);
    res->author = strdup(row[2]);
    res->next = 0;

    mysql_free_result(result);
    mysql_close(conn);

    return start;
}

struct board* NativeReadBoard(int no){
    MYSQL *conn = NativeConnectDatabase(SERVER, USER, PASSWORD, DATABASE);
    if(conn == 0) return ERROR; 

    char *query = (char *)malloc(0x1000);
    memset(query, 0, 0x1000);

    snprintf(query, 0x1000, "SELECT no, title, category, content, file, author FROM `board` WHERE no=%d", no);
    if( mysql_query(conn, query) != 0 ){
        perror("mysql_query");
        free(query);
        mysql_close(conn);
        return ERROR;
    }
    free(query);

    MYSQL_RES *result = mysql_store_result(conn);  
    int count = mysql_num_rows(result);

    if(count == 0){
      mysql_free_result(result);
      mysql_close(conn);
      return 0;
    }

    struct board *res = (struct board *)malloc(sizeof(struct board));
    memset(res, 0, sizeof(struct board));
  
    MYSQL_ROW row = mysql_fetch_row(result);
    res->no = atoi(row[0]);
    res->title = strdup(row[1]);
    res->category = strdup(row[2]);
    res->content = strdup(row[3]);
    res->file = strdup(row[4]);
    res->author = strdup(row[5]);

    mysql_free_result(result);
    mysql_close(conn);

    return res;
}

////////////////////////////////////////////// NODE WRAPPER //////////////////////////////////////////////

void dbg_(char *ptr){
  printf("DEBUG_NATIVE : %s\n", ptr);
}

namespace module {

using v8::Exception;
using v8::FunctionCallbackInfo;
using v8::Isolate;
using v8::Context;
using v8::Local;
using v8::Number;
using v8::Object;
using v8::String;
using v8::Value;
using v8::Array;

void ModuleLogin(const FunctionCallbackInfo<Value>& args) {
  dbg_("ModuleLogin");
  Isolate* isolate = args.GetIsolate();
  Local<Context> context = isolate->GetCurrentContext();

  if (args.Length() != 2) {
    isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "argc must be 2").ToLocalChecked()));
    return;
  }

  v8::String::Utf8Value id_(isolate, args[0]);
  std::string id(*id_);
  
  v8::String::Utf8Value pw_(isolate, args[1]);
  std::string pw(*pw_);

  if(NativeLogin(id.c_str(), pw.c_str()) == SUCCESS){
    args.GetReturnValue().Set(SUCCESS);
  } else {
    args.GetReturnValue().Set(ERROR);
  }
}

void ModuleRegister(const FunctionCallbackInfo<Value>& args) {
  dbg_("ModuleRegister");
  Isolate* isolate = args.GetIsolate();
  Local<Context> context = isolate->GetCurrentContext();

  if (args.Length() != 2) {
    isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "argc must be 2").ToLocalChecked()));
    return;
  }

  v8::String::Utf8Value id_(isolate, args[0]);
  std::string id(*id_);
  
  v8::String::Utf8Value pw_(isolate, args[1]);
  std::string pw(*pw_);

  if(NativeRegister(id.c_str(), pw.c_str()) == SUCCESS){
    args.GetReturnValue().Set(SUCCESS);
  } else {
    args.GetReturnValue().Set(ERROR);
  }
}

void ModuleWriteBoard(const FunctionCallbackInfo<Value>& args) {
  dbg_("ModuleBoard");
  Isolate* isolate = args.GetIsolate();
  Local<Context> context = isolate->GetCurrentContext();

  if (args.Length() != 5) {
    isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "argc must be 5").ToLocalChecked()));
    return;
  }

  v8::String::Utf8Value title_(isolate, args[0]);
  std::string title(*title_);
  
  v8::String::Utf8Value category_(isolate, args[1]);
  std::string category(*category_);

  v8::String::Utf8Value content_(isolate, args[2]);
  std::string content(*content_);

  v8::String::Utf8Value file_(isolate, args[3]);
  std::string file(*file_);

  v8::String::Utf8Value author_(isolate, args[4]);
  std::string author(*author_);

  if(NativeWriteBoard(title.c_str(), category.c_str(), content.c_str(), file.c_str(), author.c_str()) == SUCCESS){
    args.GetReturnValue().Set(SUCCESS);
  } else {
    args.GetReturnValue().Set(ERROR);
  }
}

void ModuleGetFilePath(const FunctionCallbackInfo<Value>& args) {
  dbg_("ModuleGetFilePath");
  Isolate* isolate = args.GetIsolate();
  Local<Context> context = isolate->GetCurrentContext();

  if (args.Length() != 1) {
    isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "argc must be 5").ToLocalChecked()));
    return;
  }

  if (!args[0]->IsNumber()) {
    isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "argument must be integer").ToLocalChecked()));
    return;
  }
  
  int no = args[0].As<Number>()->Value();

  const char *path = NativeGetFilePath(no);
  if(path != ERROR){
    args.GetReturnValue().Set(String::NewFromUtf8(isolate, path).ToLocalChecked());
  } else {
    args.GetReturnValue().Set(ERROR);
  }
}

void ModuelCheckAuthor(const FunctionCallbackInfo<Value>& args) {
  dbg_("ModuleCheckAuthor");
  Isolate* isolate = args.GetIsolate();
  Local<Context> context = isolate->GetCurrentContext();

  if (args.Length() != 2) {
    isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "argc must be 2").ToLocalChecked()));
    return;
  }

  if (!args[0]->IsNumber()) {
    isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "argument1 must be integer").ToLocalChecked()));
    return;
  }
  
  int no = args[0].As<Number>()->Value();

  v8::String::Utf8Value author_(isolate, args[1]);
  std::string author(*author_);

  if(NativeCheckAuthor(no, author.c_str()) == SUCCESS){
    args.GetReturnValue().Set(SUCCESS);
  } else {
    args.GetReturnValue().Set(ERROR);
  }
}

void ModuleListBoard(const FunctionCallbackInfo<Value>& args) {
  dbg_("ModuleListBoard");
  Isolate* isolate = args.GetIsolate();
  Local<Context> context = isolate->GetCurrentContext();

  if (args.Length() != 2) {
    isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "argc must be 2").ToLocalChecked()));
    return;
  }

  v8::String::Utf8Value category_(isolate, args[0]);
  std::string category(*category_);

  v8::String::Utf8Value author_(isolate, args[1]);
  std::string author(*author_);

  struct board* res = 0;
  int cnt = 0;

  if((res = NativeListBoard(category.c_str(), author.c_str())) != 0){
    Local<Array> resultArray = Array::New(isolate);

    while(res != 0){
      Local<Object> obj = Object::New(isolate);
      obj->Set(context, String::NewFromUtf8(isolate, "no").ToLocalChecked(), v8::String::NewFromUtf8(isolate, std::to_string(res->no).c_str()).ToLocalChecked());
      obj->Set(context, String::NewFromUtf8(isolate, "title").ToLocalChecked(), v8::String::NewFromUtf8(isolate, (res->title)).ToLocalChecked());
      obj->Set(context, String::NewFromUtf8(isolate, "author").ToLocalChecked(), v8::String::NewFromUtf8(isolate, (res->author)).ToLocalChecked());
      resultArray->Set(context, cnt++, obj);
      res = res->next;
    } // TODO: node 14.4.0
    
    args.GetReturnValue().Set(resultArray);
  } else {
    args.GetReturnValue().Set(ERROR);
  }
}

void ModuleReadBoard(const FunctionCallbackInfo<Value>& args) {
  dbg_("ModuleReadBoard");
  Isolate* isolate = args.GetIsolate();
  Local<Context> context = isolate->GetCurrentContext();

  if (args.Length() != 1) {
    isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "argc must be 1").ToLocalChecked()));
    return;
  }

 if (!args[0]->IsNumber()) {
    isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "argument1 must be integer").ToLocalChecked()));
    return;
  }
  
  int no = args[0].As<Number>()->Value();

  struct board* res = 0;

  if((res = NativeReadBoard(no)) != 0){
    Local<Object> obj = Object::New(isolate);
    obj->Set(context, String::NewFromUtf8(isolate, "no").ToLocalChecked(), v8::String::NewFromUtf8(isolate, std::to_string(res->no).c_str()).ToLocalChecked());
    obj->Set(context, String::NewFromUtf8(isolate, "title").ToLocalChecked(), v8::String::NewFromUtf8(isolate, (res->title)).ToLocalChecked());
    obj->Set(context, String::NewFromUtf8(isolate, "author").ToLocalChecked(), v8::String::NewFromUtf8(isolate, (res->author)).ToLocalChecked());
    obj->Set(context, String::NewFromUtf8(isolate, "content").ToLocalChecked(), v8::String::NewFromUtf8(isolate, (res->content)).ToLocalChecked());
    obj->Set(context, String::NewFromUtf8(isolate, "file").ToLocalChecked(), v8::String::NewFromUtf8(isolate, (res->file)).ToLocalChecked());
    obj->Set(context, String::NewFromUtf8(isolate, "category").ToLocalChecked(), v8::String::NewFromUtf8(isolate, (res->category)).ToLocalChecked());

    args.GetReturnValue().Set(obj);
  } else {
    args.GetReturnValue().Set(ERROR);
  }
}

void ModuleEncrypt(const FunctionCallbackInfo<Value>& args) {
  dbg_("ModuleEncrypt");
  Isolate* isolate = args.GetIsolate();
  Local<Context> context = isolate->GetCurrentContext();

  if (args.Length() != 1) {
    isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "argc must be 1").ToLocalChecked()));
    return;
  }
  
  v8::String::Utf8Value text_(isolate, args[0]);
  std::string text(*text_);

  struct AES_ctx ctx;
  char *txt = padding((char *)text.c_str());
  printf("%s\n", txt);
  char *result = (char *)malloc(strlen(txt) + 1);
  memset(result, 0, strlen(txt) + 1);

  AES_init_ctx_iv(&ctx, key, iv);

  AES_CBC_encrypt_bufferEx(&ctx, (uint8_t*)txt, (uint8_t*)result, strlen(txt));   

  char *enc = b64_encode((const unsigned char *)result, strlen(txt));

  args.GetReturnValue().Set(v8::String::NewFromUtf8(isolate, enc).ToLocalChecked());
}

void ModuleDecrypt(const FunctionCallbackInfo<Value>& args) {
  dbg_("ModuleDecrypt");
  Isolate* isolate = args.GetIsolate();
  Local<Context> context = isolate->GetCurrentContext();

  if (args.Length() != 1) {
    isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "argc must be 1").ToLocalChecked()));
    return;
  }

  v8::String::Utf8Value text_(isolate, args[0]);
  std::string text(*text_);

  struct AES_ctx ctx;
  int size = b64_decoded_size(text.c_str())+1;
  char *b64de = (char *)malloc(size);
  memset(b64de, 0, size);

  b64_decode(text.c_str(), (uint8_t*)b64de, size);
  
  AES_init_ctx_iv(&ctx, key, iv);

  AES_CBC_decrypt_buffer(&ctx, (uint8_t*)b64de, size-1);   
  b64de[size-1] = 0;

  b64de = unpadding(b64de);

  args.GetReturnValue().Set(v8::String::NewFromUtf8(isolate, b64de).ToLocalChecked());
}


void Initialize(Local<Object> exports) {
  NODE_SET_METHOD(exports, "login", ModuleLogin);
  NODE_SET_METHOD(exports, "register", ModuleRegister);
  NODE_SET_METHOD(exports, "writeBoard", ModuleWriteBoard);
  NODE_SET_METHOD(exports, "getFilePath", ModuleGetFilePath);
  NODE_SET_METHOD(exports, "checkAuthor", ModuelCheckAuthor);
  NODE_SET_METHOD(exports, "listBoard", ModuleListBoard);
  NODE_SET_METHOD(exports, "readBoard", ModuleReadBoard);
  NODE_SET_METHOD(exports, "encrypt", ModuleEncrypt);
  NODE_SET_METHOD(exports, "decrypt", ModuleDecrypt);
}

NODE_MODULE(NODE_GYP_MODULE_NAME, Initialize)

}