sqli => file download 시나리오.

1. JWT token을 조져서 임의 userID를 쓸 수 있음 ( 빠질수도 있음 ) => aes cbc 방식 토큰 하나 만들고, 하나 비트플립 시켜서 `'` 로 바꿔서 sqli
2. uploadPath를 조질 수 있고, file download가 됨.
3. 이를 이용해서 module.node 꺼낼 수 있음.
4. 웹은 여기서 /flag를 받으면 끝남.

TODO: listBoard, readBoard 완성 & aes cbc 토큰 완성 & register시 `'` 필터링 ( replace ) 

pwn
1. 웹에서 다운로드 취약점 이용하면 memory leak 됨. (node 모듈은 일단 켜져있고, maps 읽으면 뎀)
2. 여차저차 해서 rce 따고 /flag_oinsinfiaondgbaiousdnfoasndiufj 읽으면뎀
