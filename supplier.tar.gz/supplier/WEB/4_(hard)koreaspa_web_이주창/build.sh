docker rmi koreaspa
docker build . -t koreaspa