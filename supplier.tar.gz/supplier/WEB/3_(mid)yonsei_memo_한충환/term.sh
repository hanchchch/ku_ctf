#!/bin/bash
docker kill kuctf_yonsei_memo 2>/dev/null
docker rm kuctf_yonsei_memo 2>/dev/null
docker rmi yonsei_memo 2>/dev/null