docker run -it -p 31009:8080 --name kuctf_yonsei_memo yonsei_memo
