docker rmi yonsei_memo
docker build . -t yonsei_memo