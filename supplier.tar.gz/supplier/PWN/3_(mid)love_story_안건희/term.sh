#!/bin/bash
docker kill kuctf_love_story 2>/dev/null
docker rm kuctf_love_story 2>/dev/null
docker rmi love_story 2>/dev/null