#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int hogamdo = 0x100;
int count = 3;
int fd;
char *memo_arr[4];
char *chat_arr[4];
char M_name[512] = {0, };
char H_name[512] = {0, };
FILE *fp;


//main func
void main_menu();
void date_menu();
void self_menu();
void goback();
//main func

//date func
void dine();
void chat();
void travle();
void movie();
//date func

void print_line() {
	puts("-----------------------------------");
}

void set() {
	fflush(stdin);
	fflush(stdout);
	fflush(stderr);
	setvbuf(stdin, 0LL, 1, 0LL);
	setvbuf(stdout, 0LL, 1, 0LL);
	setvbuf(stderr, 0LL, 1, 0LL);
	fp = fopen("flag", "r");
	fd = fp->_fileno;
}

void status() {
	print_line();
	printf("My name is : %s\n", M_name);
	printf("Her name is : %s\n", H_name);
	printf("Hogamdo : %#x\n", hogamdo);
	print_line();
}

int read_int() {
    	char str[512];
	memset(str, 0, 512);    
	fgets(str, 0x100, stdin);
	
	if(strlen(str) == 0) {
		puts("Error!");
		exit(-1);
    	}
    	if(str[strlen(str) - 1] == '\n')
		str[strlen(str) - 1] = 0;
	if((unsigned char)(str[0] - 0x30) > 9) {
		puts("No..!!");
		exit(-1);
	}
   	return atoi(str); 
}

void broke_up() {
	int i;
	print_line();
	puts("\nFXXK..........!!!!!!!!!!");
	puts("Now I broke up... T.T\n\n");
	for (i = 0; i < 20; ++i)
		puts("GAME... OVER....");
	putchar('\n');
	print_line();
	exit(0);
}

int main() {
	set();
	main_menu();
	broke_up();
}

void main_menu() {
 	char buf[128];
	memset(buf, 0, 128);
	do {
		if(hogamdo <= 0)
			broke_up();

		if(count <= 0) {
			print_line();
			puts("Day is over....");
			puts("Your energy has been restored");
			count = 3;
			print_line();
		}
		print_line();
		puts("[N]ame setting");
		puts("[D]ate with somenyeo");
		puts("[P]lay alone");
		puts("[S]leeeeeeep...");
		puts("[C]onfession...♥");
		puts("[I]nformation");
		puts("[Q]uit");
		print_line();
		printf(" > ");
		
		fgets(buf, 0x10, stdin);
		
		if(buf[0] == 's' || buf[0] == 'S') {
			print_line();
			puts("Day is over....");
			puts("Your energy has been restored.");
			count = 3;
			hogamdo -= 0x10;
			print_line();
		}
		else if(buf[0] == 'n' || buf[0] == 'N') {
			char ch;
			print_line();
			puts("[M]y self");
			puts("[H]er...♥");
			puts("[Q]uit...");
			print_line();
			printf(" > ");
			scanf("%c",&ch);
			getchar();
			if(ch == 'm' || ch == 'M') {
				printf("Input My Name...♥ : ");
				fgets(M_name, 511, stdin);
				if(M_name[strlen(M_name) - 1] == '\n')
					M_name[strlen(M_name) - 1] = '\0';
				printf("Your name is %s.. Good Luck!!\n", M_name);
			}
			else if(ch == 'H' || ch == 'h') {
				printf("Input her name...♥ : ");
				fgets(H_name, 511, stdin);
				if(H_name[strlen(H_name) - 1] == '\n') 
					H_name[strlen(H_name) - 1] = '\0';
				printf("Her name is %s..♥ Cheer up! love!!\n", H_name);
			}

		}
		else if(buf[0] == 'd' || buf[0] == 'D') { 
			date_menu();
			--count;
		}
		else if(buf[0] == 'p' || buf[0] == 'P'){
			self_menu();
			--count;
		}
		else if(buf[0] == 'C' || buf[0] == 'c') {
			goback();
			--count;
		}
		else if(buf[0] == 'I' || buf[0] == 'i') {
			status();
		}
	} while(buf[0] != 'q' && buf[0] != 'Q');
	return;
}

void goback() {
	int i;
	char buf[256];
	if (hogamdo < 0x300) {
		puts("Her : No...!!!\n");
		broke_up();
	}
	else {
		puts("Her : I Love You To......yes...♥\n");
		for (i = 0; i < 20; ++i)
			puts("Happy Ending...♥");
		read(fd, buf, 100);
		printf("Her : ");
		puts(buf);
		fclose(fp);
		exit(0);
	}
}

void date_menu() {
	char buf[256];
	memset(buf, 0, 256);
	do{
		print_line();
		puts("[D]ine with her");
		puts("[T]ake a walk with her");
		puts("[C]hat with her");
		puts("[G]o travel with her");
		puts("[W]atch a movie with her");
		print_line();
		printf(" > ");

		fgets(buf, 0x10, stdin);

		if (buf[0] == 'D' || buf[0] == 'd') {
			dine();
			return;
		}
		
		else if (buf[0] == 'T' || buf[0] == 't') {
			if(hogamdo >= 0x200) {
				puts("I walked together holding her hand...♥");
				hogamdo += 0x10;
			}
			else {
				hogamdo += 4;
				puts("I walked with her... ♥");
			}
			return;
		}

		else if (buf[0] == 'C' || buf[0] == 'c') {
			chat();
			return;
		}
		else if (buf[0] == 'G' || buf[0] == 'g') {
			travle();
			return;
		}
		else if (buf[0] == 'W' || buf[0] == 'w') {
			movie();
			return;
		}

	} while(1);
	return;
}

void dine() {
	char buf[256];
	memset(buf, 0, 256);
	do{
		print_line();
		puts("[C]onvenience");
		puts("[T]teokbokki ");
		puts("[K]imbop");
		puts("[F]ine dining restaurant");
		print_line();
		printf(" > ");

		fgets(buf, 0x10, stdin);
		
		if(buf[0] == 'C' || buf[0] == 'c') {
			puts("Her : um..not bad...");
			hogamdo -= 8;
			return;
		}
		
		else if(buf[0] == 't' || buf[0] == 'T') {
			if(hogamdo < 0x120) {
				puts("Her : umm...Not bad...?");
				hogamdo -= 1;
			}
			else {
				puts("Her : Hmm~ so bad!!!! :) (J/K)");
				hogamdo += 8;
			}
			return;
		}
		
		else if(buf[0] == 'K' || buf[0] == 'k') {
			if(hogamdo >= 0x150) {
				puts("Her : I want to eat at \"go geup restaurant...\"");
				hogamdo += 8;
			}
			else {
				puts("Her : Nyam Nyam...");
				hogamdo += 1; }
			return;
		}
		
		else if(buf[0] == 'F' || buf[0] == 'f') {
			if(hogamdo >= 0x200) {
				char a[256];
				puts("Her : Wow..!! Really good..!!!♥");
				puts("Her : I Love it!");
				puts(":thinking: (Leave a note?(L) Or delete the note?(F))");
				
				fgets(a, 0x10, stdin);
				
				if(a[0] == 'F' || a[0] == 'f') {
					int idx = 0;
					puts("Me : Where you want?");
					printf(" > ");
					idx = read_int();
					if(idx < 0 || idx > 3 ) {
						puts("OOB!?!? You can't!");
						puts("Error...");
						exit(-1);
					}
					if(memo_arr[idx] != NULL) {
						puts("Her : Hmm... I want to clear this memo..");
						free(memo_arr[idx]);
						memo_arr[idx] = (char*)NULL;
						puts("success!");
						return;
					}
					else puts("Her : Ah..? didn't exist..!!");
				}
				
				else if (a[0] == 'l' || a[0] == 'L') {
					int size = 0;
					puts("Her : I want to leave a memo...♥");

					for(int i = 0; i < 4; ++i) {
						if(memo_arr[i] == (char*)NULL) {
							puts("Me : How long ?");
							printf(" > ");
							size = read_int();

							if (size <= 0) {
								puts("No..!! Error..!!");
								exit(-1);
							}

							else if (size >= 0x60) {
								puts("Me : Hey..!! That's too long..!!!");
								puts(":thinking: (can't leave memo..)");
							}

							else {
								memo_arr[i] = malloc(size);
								if(memo_arr[i] == NULL) {
									puts("Error..! Contact us..!");
									exit(-1);
								}
								printf("memo : ");
								fgets(memo_arr[i], size + 1, stdin); 
								if(memo_arr[i][strlen(memo_arr[i]) - 1] != '\0')
									memo_arr[i][strlen(memo_arr[i])] = '\0'; //off-by-one
								puts("success!");
								return;
							}
						}
						else {
							puts(":thinking: (memo is full...)");
							puts("Me : we can't leave a memo T.T..");
						}
					}
				}
				hogamdo += 0x20;
			}
			else {
				puts("Sorry. I feel a little burdened...");
				hogamdo -= 0x8;
			}
			return;
		}
	} while(1);
}

void chat() {
	int i;
	char buf[256];
	int idx;
	int size;
	memset(buf, 0, 256);
	if(hogamdo < 0x120) {
		puts("Me : Hey! Hi~!");
		puts("Her : /ban Me");
		return;
	}

	do{
		print_line();
		puts("[V]iew chat");
		puts("[D]elete chat");
		puts("[A]dd chat");
		print_line();
		printf(" > "); 
		
		fgets(buf,0x10, stdin);

		if(buf[0] == 'v' || buf[0] == 'V') {
			for (i = 0; i < 4; ++i) {
				if(chat_arr[i] != NULL) {
					print_line();
					puts(chat_arr[i] + 8);
					print_line();
				}
			}
			return;
		}

		else if(buf[0] == 'd' || buf[0] == 'D') {
			puts(":thinking: (hmm... where?)");
			printf(" > ");
			idx = read_int();

			if(idx < 0 || idx > 3) {
				puts("OOB!?!? You can't!");
				puts("Error...");
				exit(-1);
			}

			if(chat_arr[idx] != NULL) {
				free(chat_arr[idx]);
				chat_arr[idx] = (char*)NULL;
				puts("success!");
				return;
			}
			else 
				puts(":thinking: (hmm... didn't exist..)");
			return;
		}

		else if(buf[0] == 'a' || buf[0] == 'A') {
			for (i = 0; i < 4; ++i) {
				if(chat_arr[i] == NULL) {
					puts("How long?");
					printf(" > ");
					size = read_int();
					
					if(size < 0x80) {
						puts(":thinking: (hmm.. so small...)");
					}

					else {
						chat_arr[i] = malloc(size);

						if(chat_arr[i] == NULL) {
							puts("Error..! contact us..!");
							exit(-1);
						}

						puts("Me : Hi!! What are you doing right now?");
						puts("Her : blah.. blah..");
						printf("Me : ");
						fgets(chat_arr[i], size, stdin);
						if(chat_arr[i][strlen(chat_arr[i]) - 1])
							chat_arr[i][strlen(chat_arr[i]) - 1] = '\0';
						puts("success!");
						return;
						
					}
				}
			}
		}
	} while(1);
	hogamdo += 0x10;
}

void travle() {
	if(hogamdo < 0x200) {
		puts("Her : ....? Are you crazy..?");
		broke_up();
	}
	puts("Her : I like the sea... at night...♥");
	puts("Me : I think so...♥");
	hogamdo += 0x20;
	return;
}

void movie() {
	char buf[256];
	do{
		print_line();
		puts("[A]ction movie");
		puts("[C]omedy movie");
		puts("[L]ove movie");
		puts("[E]rotic movie");
		print_line();
		printf(" > ");
		fgets(buf, 0x10, stdin);
		
		if(buf[0] == 'A' || buf[0] == 'a') {
			
			hogamdo += 0x8;
			puts("Her : Yeah! So Fun!!");
			return;
		}
		
		
		if(buf[0] == 'C' || buf[0] == 'c') {

			hogamdo += 0x8;
			puts("Her : HaHAHaAHAHAHaHAHA! So funny!!");
			return;
		}
		
		if(buf[0] == 'L' || buf[0] == 'l') {
			if(hogamdo < 0x150) {
				hogamdo += 0x10;
				puts("Her : Oh.. this is so romantic..♥");
			}

			else {
				hogamdo += 2;
				puts("Her : Haha....!! (awkward)");
			}
			return;
		}

		if(buf[0] == 'E' || buf[0] == 'e') {
			puts("Her : Hey..!!!!!!!!! Fxxk you!!!!");
			broke_up();
		}
	} while(1);

}

void self_menu() {
	char buf[256];
	do {
		print_line();
		puts("[W]alking the park");
		puts("[D]owntown");
		puts("[N]earby schools");
		puts("[P]C cafe");
		puts("[Q]uit");
		print_line();
		
		printf("> ");
		
		fgets(buf, 0x10, stdin);

		if(buf[0] == 'W' || buf[0] == 'w') {
			
			if(hogamdo >= 0x120) {
				puts("Her : Hey! Hi~! Where are you go?");
				puts("Me : blah blah blah...");
				puts(":thinking: (I happened to meet her... It was happy...♥)");
				hogamdo += 0x8;
			}

			else {
				puts(":thinking: (I took a walk... :) The air is good... :) )"); 
				hogamdo -= 1;
			}
		}

		else if(buf[0] == 'D' || buf[0] == 'd') {
			puts("I got to the downtown.");
			if(hogamdo >= 0x200) {
				puts("??? : Hey..?");
				puts("Me : Oh! Hi~. I'm surprised to see you here.");
				puts("Her : me too.. blah blah...");
				puts(":thinking: (I ran into him and went out on a date... I'm happy..♥)");
				hogamdo += 0x20;
			}
			else {
				puts("roam around alone I came home...");
				hogamdo -= 1;
			}
		}

		else if(buf[0] == 'N' || buf[0] == 'n') {
			puts("I came for a walk to a nearby school...");
			puts("I saw her in the distance..");
			puts(":thinking: (Is it her alma mater?)");
			puts(":thinking: (Should I talk to her?)");
			if(hogamdo >= 0x150) {
				puts("Me : Hey..!!");
				puts("Her : Umm.. Hi..~ Why are you here?");
				puts("Me : I just came for a walk.");
				puts("Me : Is this your alma mater?");
				puts("Her : Yes! I'm on my way home from my teacher!");
				puts("blah..blah...");
				hogamdo += 0x20;
			}
			
			else {
				puts(":thinking: (I just gotta go home...)");
				puts("Her : Uh, why is he here...?");
				hogamdo += 4;
			}

			return;
		}

		else if(buf[0] == 'P' || buf[0] == 'p') {
			puts(":thinking: (I arrived at the PC cafe.)");
			puts(":thinking: (The game was fun..)");
			hogamdo -= 0x20;
		}
		
	} while(buf[0] != 'q' && buf[0] != 'Q');

}
