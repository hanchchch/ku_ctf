#!/bin/bash
docker kill kuctf_love_story 2>/dev/null
docker rm kuctf_love_story 2>/dev/null
docker run --privileged -p 31005:31000 -dit --name kuctf_love_story love_story