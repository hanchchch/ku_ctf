#!/bin/bash
docker rmi love_story
docker build . -t love_story