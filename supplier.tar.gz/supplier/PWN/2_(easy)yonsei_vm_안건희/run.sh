#!/bin/bash
docker kill kuctf_yonsei_vm 2>/dev/null
docker rm kuctf_yonsei_vm 2>/dev/null
docker run --privileged -p 31004:31000 -dit --name kuctf_yonsei_vm yonsei_vm