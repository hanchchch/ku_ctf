#!/bin/bash
docker kill kuctf_yonsei_vm 2>/dev/null
docker rm kuctf_yonsei_vm 2>/dev/null
docker rmi yonsei_vm 2>/dev/null