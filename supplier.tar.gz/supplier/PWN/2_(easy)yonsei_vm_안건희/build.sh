#!/bin/bash
docker rmi yonsei_vm
docker build . -t yonsei_vm