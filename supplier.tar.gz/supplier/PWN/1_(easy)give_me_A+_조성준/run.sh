#!/bin/bash
docker kill kuctf_give_me_a 2>/dev/null
docker rm kuctf_give_me_a 2>/dev/null
docker run --privileged -p 31003:31000 -dit --name kuctf_give_me_a give_me_a