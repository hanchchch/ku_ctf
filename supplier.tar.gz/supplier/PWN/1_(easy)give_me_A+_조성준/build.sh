#!/bin/bash
docker rmi give_me_a
docker build . -t give_me_a